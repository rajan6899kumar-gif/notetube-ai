# NoteTube AI deployment package

Correct Next.js project structure:
app/
package.json
README.md

IMPORTANT:
- Add OPENAI_API_KEY as a Vercel Environment Variable.
- Configure an authorized transcript source in app/api/generate/route.js.
- Never commit a real API key to GitHub.
